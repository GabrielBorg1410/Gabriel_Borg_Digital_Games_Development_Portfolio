// To run the app go to command prompt and go to the directory of the project name and type 'ionic serve' to access the app
//To install the capacitors and modules go to command prompt and on the project folder name type 'npm install' to ensure that the app runs well
import {
  IonButton,
  IonContent,
  IonHeader,
  IonImg,
  IonInput,
  IonItem,
  IonLabel,
  IonList,
  IonPage,
  IonSelect,
  IonSelectOption,
  IonTitle,
  IonToolbar
} from '@ionic/react';

import { useState } from 'react';
import './Home.css';

const Home: React.FC = () => {

  // Movie interface
  interface Movie {
    title: string;
    genre: string;
    releaseYear: string;
    status: string;
    posterUrl: string;
  }

  // State Variables
  const [movieList, setMovieList] = useState<Movie[]>([]);

  const [movieTitle, setMovieTitle] = useState<string>("");
  const [genre, setGenre] = useState<string>("");
  const [releaseYear, setReleaseYear] = useState<string>("");
  const [status, setStatus] = useState<string>("Want to Watch");
  const [posterUrl, setPosterUrl] = useState<string>("");

  // Helper Functions

  // Render an IonItem for every movie in the movieList array
  const renderMovieList = () => {

    const renderedMovies = [];

    for (let i = 0; i < movieList.length; i++) {

      renderedMovies.push(

        <IonItem key={i} className="movie-card">

          <IonImg
            src={movieList[i].posterUrl}
            className="movie-poster"
          />

          <IonLabel>

            <h2>{movieList[i].title}</h2>

            <p>
              Genre: {movieList[i].genre}
            </p>

            <p>
              Release Year: {movieList[i].releaseYear}
            </p>

            <p>
              Status: {movieList[i].status}
            </p>

          </IonLabel>

          <IonButton
            onClick={() => handleDeleteMovie(i)}
            color="danger"
          >
            Delete
          </IonButton>

        </IonItem>

      );
    }
    return renderedMovies;
  };

  // Capture movie title input
  const handleMovieTitleInput = (event: any) => {
    setMovieTitle(event.target.value);
  };

  // Capture genre input
  const handleGenreInput = (event: any) => {
    setGenre(event.target.value);
  };

  // Capture release year input
  const handleReleaseYearInput = (event: any) => {
    setReleaseYear(event.target.value);
  };

  // Capture poster URL input
  const handlePosterUrlInput = (event: any) => {
    setPosterUrl(event.target.value);
  };

  // Capture movie status
  const handleStatusInput = (event: any) => {
    setStatus(event.detail.value);
  };

  // Add a new movie
  const handleAddMovie = () => {

    // Check if any field is empty
    if (
      movieTitle.trim() === "" ||
      genre.trim() === "" ||
      releaseYear.trim() === "" ||
      posterUrl.trim() === "" ||
      status.trim() === ""
    ) 
    {
      alert("Please fill in all fields.");
      return;
    }

    const updatedMovieList = [...movieList];

    const newMovie: Movie = {
      title: movieTitle,
      genre: genre,
      releaseYear: releaseYear,
      status: status,
      posterUrl: posterUrl
    };

    updatedMovieList.push(newMovie);

    // Update movieList state
    setMovieList(updatedMovieList);

    // Refresh the inputs
    setMovieTitle("");
    setGenre("");
    setReleaseYear("");
    setStatus("Want to Watch");
    setPosterUrl("");
  };

  // Delete selected movie
  const handleDeleteMovie = (indexToDelete: number) => {

    const updatedMovieList = [];

    for (let i = 0; i < movieList.length; i++) {

      if (i !== indexToDelete) {updatedMovieList.push(movieList[i]);}
    }
    setMovieList(updatedMovieList);
  };

  return (

    <IonPage>

      <IonHeader>

        <IonToolbar color="primary">
          <IonTitle>Movie Watchlist</IonTitle>
        </IonToolbar>

      </IonHeader>

      <IonContent className="ion-padding">

        <IonList>

          {renderMovieList()}

          <IonItem>

            <IonInput
              label="Movie Title"
              labelPlacement="stacked"
              placeholder="Enter movie title"
              value={movieTitle}
              onIonInput={handleMovieTitleInput}
              required
            />

          </IonItem>

          <IonItem>

            <IonInput
              label="Genre"
              labelPlacement="stacked"
              placeholder="Enter movie genre"
              value={genre}
              onIonInput={handleGenreInput}
              required
            />

          </IonItem>

          <IonItem>

            <IonInput
              label="Release Year"
              labelPlacement="stacked"
              type="number"
              placeholder="Enter release year"
              value={releaseYear}
              onIonInput={handleReleaseYearInput}
              required
            />

          </IonItem>

          <IonItem>

            <IonInput
              label="Poster URL"
              labelPlacement="stacked"
              type="url"
              placeholder="Enter movie poster URL"
              value={posterUrl}
              onIonInput={handlePosterUrlInput}
              required
            />

          </IonItem>

          <IonItem>

            <IonSelect
              label="Status"
              labelPlacement="stacked"
              value={status}
              onIonChange={handleStatusInput}
              required
            >

              <IonSelectOption value="Want to Watch">
                Want to Watch
              </IonSelectOption>

              <IonSelectOption value="Watching">
                Watching
              </IonSelectOption>

              <IonSelectOption value="Watched">
                Watched
              </IonSelectOption>

            </IonSelect>

          </IonItem>

          <IonButton
            expand="block"
            onClick={handleAddMovie}
          >
            Add Movie
          </IonButton>

        </IonList>

      </IonContent>

    </IonPage>
  );
};
export default Home;