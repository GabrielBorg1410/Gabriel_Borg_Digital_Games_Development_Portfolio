// Get references to the form and the section where game cards will be displayed
const gameForm = document.getElementById("gameForm");
const gameList = document.getElementById("gameList");

// Get references to all input fields in the form
const gameTitle = document.getElementById("gameTitle");
const platform = document.getElementById("platform");
const genre = document.getElementById("genre");
const statusInput = document.getElementById("status");
const rating = document.getElementById("rating");
const coverImage = document.getElementById("coverImage");

// Get references to the search and filter controls
const searchInput = document.getElementById("searchInput");
const platformFilter = document.getElementById("platformFilter");
const statusFilter = document.getElementById("statusFilter");

// Load saved games from Local Storage.
// If there are no saved games, start with an empty array.
let games = JSON.parse(localStorage.getItem("games")) || [];

// Displaying the saved games when the site loads
displayGames();

// When the Add Game button is clicked run it using the event lisinter
gameForm.addEventListener("submit", function (event) {
  event.preventDefault();

  // Creating a new game object using the values that the user enters
  const game = {
    id: Date.now(),
    title: gameTitle.value.trim(),
    platform: platform.value,
    genre: genre.value.trim(),
    status: statusInput.value,
    rating: rating.value,
    cover: coverImage.value.trim()
  };

  // Adding a new game to the game array
  games.push(game);

  // The game collection will be updated and saved

  saveGames();

  // Refreshing the game cards so it does not show the placeholder image
  displayGames();

  // Clearing the whole form
  gameForm.reset();
});

// Refreshes the displayed games whenever the user searches or changes a filter
searchInput.addEventListener("input", displayGames);
platformFilter.addEventListener("change", displayGames);
statusFilter.addEventListener("change", displayGames);

// Save the games array into Local Storage
function saveGames() {
  localStorage.setItem("games", JSON.stringify(games));
}

// Display all games that match the search and filter options
// Remove all existing cards before displaying updated ones (gamesList.innerHTML = "")
function displayGames() {
  gameList.innerHTML = "";

  // Read the current search and filter values
  const searchText = searchInput.value.toLowerCase();
  const selectedPlatform = platformFilter.value;
  const selectedStatus = statusFilter.value;

  // Filter the games according to the search text and selected filters
  const filteredGames = games.filter(function (game) {
    const matchesSearch = game.title.toLowerCase().includes(searchText);
    const matchesPlatform =
      selectedPlatform === "All" || game.platform === selectedPlatform;
    const matchesStatus =
      selectedStatus === "All" || game.status === selectedStatus;

    return matchesSearch && matchesPlatform && matchesStatus;
  });

  // Display a message if no games match the filters
  if (filteredGames.length === 0) {
    gameList.innerHTML = `<p class="empty-message">No games found. Add your first game!</p>`;
    return;
  }

  // Create a card for each filtered game
  filteredGames.forEach(function (game) {
    const gameCard = document.createElement("div");
    gameCard.classList.add("game-card");

    // Filling the card with the game's information
    gameCard.innerHTML = `
      <img src="${game.cover || "https://via.placeholder.com/300x400?text=No+Image"}" alt="${game.title}">

      <div class="game-card-content">
        <h3>${game.title}</h3>
        <p><strong>Platform:</strong> ${game.platform}</p>
        <p><strong>Genre:</strong> ${game.genre}</p>
        <p><strong>Status:</strong> ${game.status}</p>
        <p><strong>Rating:</strong> ${game.rating}</p>

        <button class="delete-btn" onclick="deleteGame(${game.id})">Delete</button>
      </div>
    `;

    // Adding the card to the page by appending the gameCard array 
    gameList.appendChild(gameCard);
  });
}

// Deleting a game using its unique ID
function deleteGame(id) {
  // Keeping every game except the one that is selected for deletion
  games = games.filter(function (game) {
    return game.id !== id;
  });

  // Saving the updated game collection
  saveGames();
  // Refreshing the displayed games
  displayGames();
}