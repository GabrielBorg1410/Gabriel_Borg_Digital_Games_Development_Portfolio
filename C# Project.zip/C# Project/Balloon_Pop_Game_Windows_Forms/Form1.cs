using System;
using System.Drawing;
using System.Windows.Forms;

namespace Balloon_Pop_Game_Windows_Forms
{
    public partial class Ballon_Pop_Game : Form
    {
        int score = 0;
        int lives = 5;
        int highScore = 0;

        Random random = new Random();

        public Ballon_Pop_Game()
        {
            InitializeComponent();

            // Allows the form to detect keyboard input
            this.KeyPreview = true;

            // Connect the KeyDown event
            this.KeyDown += Ballon_Pop_Game_KeyDown;
        }

        private void SpawnBalloon()
        {
            PictureBox[] balloons =
            {
                redBalloon,
                greenBalloon,
                blueBalloon,
                yellowBalloon,
                blackBalloon
            };

            // Hide all balloons first
            foreach (PictureBox balloon in balloons)
            {
                balloon.Visible = false;
            }

            // Choose a random balloon
            PictureBox selectedBalloon = balloons[random.Next(balloons.Length)];

            // Choose a random position inside the game panel
            int randomX = random.Next(
                0,
                gamePanel.ClientSize.Width - selectedBalloon.Width
            );

            int randomY = random.Next(
                0,
                gamePanel.ClientSize.Height - selectedBalloon.Height
            );

            // Move the selected balloon
            selectedBalloon.Location =
                new Point(randomX, randomY);

            // Show the balloon
            selectedBalloon.Visible = true;

            // Start the timeout timer
            StartBalloonTimer();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            ResetGame();

            // Disable the button while playing
            startGameBtn.Enabled = false;

            // Spawn first balloon
            SpawnBalloon();

            // Move keyboard focus away from the Start button
            gamePanel.Focus();
        }

        private void redBalloon_Click(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            score++;

            gameScore.Text = "Score: " + score;

            UpdateDifficulty();

            SpawnBalloon();
        }

        private void greenBalloon_Click(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            score++;

            gameScore.Text = "Score: " + score;

            UpdateDifficulty();

            SpawnBalloon();
        }

        private void blueBalloon_Click(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            score++;

            gameScore.Text = "Score: " + score;

            UpdateDifficulty();

            SpawnBalloon();
        }

        private void yellowBalloon_Click(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            score++;

            gameScore.Text = "Score: " + score;

            UpdateDifficulty();

            SpawnBalloon();
        }

        private void blackBalloon_Click(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            // Clicking black balloon loses a life
            lives--;

            inGameLives.Text = "Lives: " + lives;

            if (lives <= 0)
            {
                EndGame();
                return;
            }

            SpawnBalloon();
        }

        private void Ballon_Pop_Game_KeyDown(object sender, KeyEventArgs e)
        {
            // Space skips the black balloon
            if (e.KeyCode == Keys.Space && blackBalloon.Visible)
            {
                // Prevent Space from activating another button
                e.SuppressKeyPress = true;

                balloonTimer.Stop();

                SpawnBalloon();
            }
        }

        private void StartBalloonTimer()
        {
            // Restart the timer every time a new balloon appears
            balloonTimer.Stop();

            balloonTimer.Start();
        }

        // Timer event for the balloons
        private void balloonTimer_Tick_1(object sender, EventArgs e)
        {
            balloonTimer.Stop();

            // Player did not react fast enough
            lives--;

            inGameLives.Text = "Lives: " + lives;

            if (lives <= 0)
            {
                EndGame();
                return;
            }

            SpawnBalloon();
        }

        // Update difficulty based on score obtained
        private void UpdateDifficulty()
        {
            if (score >= 40)
            {
                balloonTimer.Interval = 650;
            }
            else if (score >= 30)
            {
                balloonTimer.Interval = 800;
            }
            else if (score >= 20)
            {
                balloonTimer.Interval = 1000;
            }
            else if (score >= 10)
            {
                balloonTimer.Interval = 1200;
            }
            else
            {
                balloonTimer.Interval = 1500;
            }
        }

        private void EndGame()
        {
            balloonTimer.Stop();

            // Hide all balloons
            redBalloon.Visible = false;
            greenBalloon.Visible = false;
            blueBalloon.Visible = false;
            yellowBalloon.Visible = false;
            blackBalloon.Visible = false;

            // Check for new high score
            if (score > highScore)
            {
                highScore = score;
            }

            // Update high score label
            gameHighScore.Text =
                "High Score: " + highScore;

            // Show results
            MessageBox.Show(
                "Game Over!\n" +
                "Score: " + score +
                "\nHigh Score: " + highScore
            );

            // Allow player to start again
            startGameBtn.Enabled = true;
        }

        private void ResetGame()
        {
            balloonTimer.Stop();

            // Reset current game
            score = 0;
            lives = 5;

            // Update labels
            gameScore.Text = "Score: 0";
            inGameLives.Text = "Lives: 5";

            // Reset difficulty
            balloonTimer.Interval = 1500;

            // Hide all balloons before restarting
            redBalloon.Visible = false;
            greenBalloon.Visible = false;
            blueBalloon.Visible = false;
            yellowBalloon.Visible = false;
            blackBalloon.Visible = false;
        }


    }
}