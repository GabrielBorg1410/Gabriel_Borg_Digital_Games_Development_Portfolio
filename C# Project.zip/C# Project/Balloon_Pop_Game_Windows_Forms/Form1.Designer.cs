﻿namespace Balloon_Pop_Game_Windows_Forms
{
    partial class Ballon_Pop_Game
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ballon_Pop_Game));
            gameScore = new Label();
            inGameLives = new Label();
            gamePanel = new Panel();
            blackBalloon = new PictureBox();
            yellowBalloon = new PictureBox();
            redBalloon = new PictureBox();
            blueBalloon = new PictureBox();
            greenBalloon = new PictureBox();
            gameTitle = new Label();
            startGameBtn = new Button();
            balloonTimer = new System.Windows.Forms.Timer(components);
            gameHighScore = new Label();
            gamePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)blackBalloon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)yellowBalloon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)redBalloon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)blueBalloon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)greenBalloon).BeginInit();
            SuspendLayout();
            // 
            // gameScore
            // 
            gameScore.AutoSize = true;
            gameScore.Font = new Font("Showcard Gothic", 12F);
            gameScore.Location = new Point(634, 99);
            gameScore.Name = "gameScore";
            gameScore.Size = new Size(97, 26);
            gameScore.TabIndex = 0;
            gameScore.Text = "Score: 0";
            // 
            // inGameLives
            // 
            inGameLives.AutoSize = true;
            inGameLives.Font = new Font("Showcard Gothic", 12F);
            inGameLives.Location = new Point(634, 161);
            inGameLives.Name = "inGameLives";
            inGameLives.Size = new Size(85, 26);
            inGameLives.TabIndex = 1;
            inGameLives.Text = "Lives: 5";
            // 
            // gamePanel
            // 
            gamePanel.Controls.Add(blackBalloon);
            gamePanel.Controls.Add(yellowBalloon);
            gamePanel.Controls.Add(redBalloon);
            gamePanel.Controls.Add(blueBalloon);
            gamePanel.Controls.Add(greenBalloon);
            gamePanel.Location = new Point(66, 73);
            gamePanel.Name = "gamePanel";
            gamePanel.Size = new Size(511, 327);
            gamePanel.TabIndex = 2;
            // 
            // blackBalloon
            // 
            blackBalloon.BackgroundImageLayout = ImageLayout.Stretch;
            blackBalloon.Image = (Image)resources.GetObject("blackBalloon.Image");
            blackBalloon.Location = new Point(65, 188);
            blackBalloon.Name = "blackBalloon";
            blackBalloon.Size = new Size(89, 120);
            blackBalloon.TabIndex = 4;
            blackBalloon.TabStop = false;
            blackBalloon.Click += blackBalloon_Click;
            // 
            // yellowBalloon
            // 
            yellowBalloon.Image = (Image)resources.GetObject("yellowBalloon.Image");
            yellowBalloon.Location = new Point(344, 53);
            yellowBalloon.Name = "yellowBalloon";
            yellowBalloon.Size = new Size(92, 119);
            yellowBalloon.TabIndex = 3;
            yellowBalloon.TabStop = false;
            yellowBalloon.Click += yellowBalloon_Click;
            // 
            // redBalloon
            // 
            redBalloon.BackgroundImageLayout = ImageLayout.Stretch;
            redBalloon.Image = (Image)resources.GetObject("redBalloon.Image");
            redBalloon.Location = new Point(65, 53);
            redBalloon.Name = "redBalloon";
            redBalloon.Size = new Size(84, 120);
            redBalloon.TabIndex = 2;
            redBalloon.TabStop = false;
            redBalloon.Click += redBalloon_Click;
            // 
            // blueBalloon
            // 
            blueBalloon.BackgroundImageLayout = ImageLayout.Stretch;
            blueBalloon.Image = (Image)resources.GetObject("blueBalloon.Image");
            blueBalloon.Location = new Point(250, 53);
            blueBalloon.Name = "blueBalloon";
            blueBalloon.Size = new Size(88, 119);
            blueBalloon.TabIndex = 1;
            blueBalloon.TabStop = false;
            blueBalloon.Click += blueBalloon_Click;
            // 
            // greenBalloon
            // 
            greenBalloon.BackgroundImageLayout = ImageLayout.Stretch;
            greenBalloon.Image = (Image)resources.GetObject("greenBalloon.Image");
            greenBalloon.Location = new Point(155, 53);
            greenBalloon.Name = "greenBalloon";
            greenBalloon.Size = new Size(89, 119);
            greenBalloon.TabIndex = 0;
            greenBalloon.TabStop = false;
            greenBalloon.Click += greenBalloon_Click;
            // 
            // gameTitle
            // 
            gameTitle.AutoSize = true;
            gameTitle.Font = new Font("Showcard Gothic", 12F, FontStyle.Bold | FontStyle.Italic);
            gameTitle.Location = new Point(281, 9);
            gameTitle.Name = "gameTitle";
            gameTitle.Size = new Size(221, 26);
            gameTitle.TabIndex = 3;
            gameTitle.Text = "BALLOON POP GAME";
            // 
            // startGameBtn
            // 
            startGameBtn.Font = new Font("Showcard Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            startGameBtn.Location = new Point(634, 277);
            startGameBtn.Name = "startGameBtn";
            startGameBtn.Size = new Size(127, 34);
            startGameBtn.TabIndex = 4;
            startGameBtn.Text = "Start Game";
            startGameBtn.UseVisualStyleBackColor = true;
            // 
            // balloonTimer
            // 
            balloonTimer.Interval = 1500;
            balloonTimer.Tick += balloonTimer_Tick_1;
            // 
            // gameHighScore
            // 
            gameHighScore.AutoSize = true;
            gameHighScore.Font = new Font("Showcard Gothic", 12F);
            gameHighScore.Location = new Point(634, 219);
            gameHighScore.Name = "gameHighScore";
            gameHighScore.Size = new Size(154, 26);
            gameHighScore.TabIndex = 5;
            gameHighScore.Text = "High Score: 0";
            // 
            // Ballon_Pop_Game
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(gameHighScore);
            Controls.Add(startGameBtn);
            Controls.Add(gameTitle);
            Controls.Add(gamePanel);
            Controls.Add(inGameLives);
            Controls.Add(gameScore);
            Name = "Ballon_Pop_Game";
            Text = "Form1";
            KeyDown += Ballon_Pop_Game_KeyDown;
            gamePanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)blackBalloon).EndInit();
            ((System.ComponentModel.ISupportInitialize)yellowBalloon).EndInit();
            ((System.ComponentModel.ISupportInitialize)redBalloon).EndInit();
            ((System.ComponentModel.ISupportInitialize)blueBalloon).EndInit();
            ((System.ComponentModel.ISupportInitialize)greenBalloon).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label gameScore;
        private Label inGameLives;
        private Panel gamePanel;
        private Label gameTitle;
        private Button startGameBtn;
        private PictureBox greenBalloon;
        private PictureBox blackBalloon;
        private PictureBox yellowBalloon;
        private PictureBox redBalloon;
        private PictureBox blueBalloon;
        private System.Windows.Forms.Timer balloonTimer;
        private Label gameHighScore;
    }
}
