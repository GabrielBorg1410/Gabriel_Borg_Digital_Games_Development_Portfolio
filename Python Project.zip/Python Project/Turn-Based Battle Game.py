import random

#Fighter Class
class Fighter:
    def __init__(self, name, fighter_class, health, attack_min, attack_max, defense):
        self.name = name
        self.fighter_class = fighter_class
        self.max_health = health
        self.health = health
        self.attack_min = attack_min
        self.attack_max = attack_max
        self.defense = defense

    def attack(self):
        return random.randint(self.attack_min, self.attack_max)

    def heavy_attack(self):
        hit_chance = random.randint(1, 100)

        if hit_chance <=60:
            damage = random.randint(self.attack_min, self.attack_max + 15)
            return damage
        return 0

    def heal(self):
        heal_amount = random.randint(15, 30)

        self.health += heal_amount

        if self.health > self.max_health:
            self.health = self.max_health

        return heal_amount

    def take_damage(self, damage):
        actual_damage = damage - self.defense

        if actual_damage < 0:
            actual_damage = 0

        self.health -= actual_damage

        if self.health < 0:
            self.health = 0

        return actual_damage

    def is_alive(self):
        return self.health > 0

    def show_stats(self):
        print(f"Name: {self.name}")
        print(f"Class: {self.fighter_class}")
        print(f"Health: {self.health}/{self.max_health}")
        print(f"Attack: {self.attack_min}-{self.attack_max}")
        print(f"Defense: {self.defense}")

#Game Title
        
print("=========================")
print("=============TURN-BASED BATTLE GAME=============")
print("=========================")

#Player Name

player_name = input("Enter your fighter name: ")

#Player Fighter Selection

print("\nChoose your fighter to play with:")
print("1. Warrior")
print("2. Assassin")
print("3. Knight")

fighter_choice = input("\nChoose 1, 2 or 3: ")

if fighter_choice == "1":
    player = Fighter(player_name, "Warrior", 110, 15, 25, 5)

elif fighter_choice == "2":
    player = Fighter(player_name, "Assassin", 85, 20, 32, 2)

elif fighter_choice == "3":
    player = Fighter(player_name, "Knight", 130, 12, 20, 8)

else:
    print("\nInvalid choice. Warrior selected by default.")
    
    player = Fighter(player_name, "Warrior", 110, 15, 25, 5)

#Enemy

enemy = Fighter("Dark Knight", "Enemy", 120, 15, 25, 4)

#Player Information Stats

print("=========================")
print("=============YOUR FIGHTER=============")
print("=========================")

player.show_stats()

#Enemy Information Stats

print("=========================")
print("=============Enemy=============")
print("=========================")

enemy.show_stats()

input("\nPress ENTER to begin the battle...")

#Game Battle Loop

while player.is_alive() and enemy.is_alive():
    print("\n-------------------------")
    print(f"{player.name} ({player.fighter_class})")
    print(f"HP: {player.health}/{player.max_health}")

    print()

    print(enemy.name)
    print(f"HP: {enemy.health}/{enemy.max_health}")
    print("-------------------------")

    print("1. Attack")
    print("2. Heavy Attack")
    print("3. Heal")

    choice = input("Choose an action: ")

    #Normal Attack
    if choice == "1":
        damage = player.attack()
        actual_damage = enemy.take_damage(damage)

        print(f"\nYou attacked {enemy.name} for {actual_damage} damage!")

    #Heavy Attack
    elif choice == "2":
        damage = player.heavy_attack()
        
        if damage > 0:
            actual_damage = enemy.take_damage(damage)
            print(f"\nHeavy attack hit for {actual_damage} damage!")

        else:
            print("\nHeavy attack missed!")

    #Heal
    elif choice == "3":
        previous_health = player.health
        player.heal()
        actual_healing = player.health - previous_health
        print(f"\nYou restored {actual_healing} HP!")

    else:
        print("\nHealth already at maximum health.")
        continue

    #Check Enemy Health
    if not enemy.is_alive():
        break

    #Enemy Attack
    
    enemy_damage = enemy.attack()
    actual_damage = player.take_damage(enemy_damage)

    if actual_damage < 0:
        actual_damage = 0

    print(f"The enemy attacked you for {actual_damage}!")

#Game Over
    
print("\n=========================")

if player.is_alive():
    print("VICTORY")
    print(f"\n{player.name} WINS THE BATTLE against the {enemy.name}!")
else:
    print("DEFEAT")
    print(f"\n{player.name} LOST THE BATTLE against the {enemy.name}!")

print("=========================")
