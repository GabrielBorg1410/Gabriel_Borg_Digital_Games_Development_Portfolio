// Information for each programming language/software
const languageInfo = {

    csharp: {
        title: "C#",
        description:
            "C# is a programming language developed by Microsoft. " +
            "It is commonly used for desktop applications, web applications, " +
            "and game development using Unity."
    },

    cpp: {
        title: "C++",
        description:
            "C++ is a powerful programming language commonly used for " +
            "game development, operating systems, desktop applications " +
            "and high-performance software."
    },

    html: {
    title: "HTML, CSS & JavaScript",
    description:
        "HTML, CSS and JavaScript are core technologies used in web development. " +
        "HTML structures the content of a web page, CSS controls its appearance " +
        "and layout, while JavaScript adds interactivity and functionality."
},

    python: {
        title: "Python",
        description:
            "Python is a popular programming language known for its simple " +
            "syntax. It is used for web development, automation, artificial " +
            "intelligence, data science and software development."
    },

    unity: {
        title: "Unity",
        description:
            "Unity is a game development engine used to create 2D and 3D games. " +
            "Unity mainly uses C# for programming game behaviour."
    }

};


// Get the information box
const infoBox = document.querySelector("#infoBox");
const infoTitle = document.querySelector("#infoTitle");
const infoDescription = document.querySelector("#infoDescription");
const closeButton = document.querySelector("#closeInfo");


// Get every programming poster
const posters = document.querySelectorAll(".languagePoster");


// Detect poster clicks
posters.forEach(function (poster) {

    poster.addEventListener("click", function () {

        const language = poster.getAttribute("data-language");

        const information = languageInfo[language];

        infoTitle.setAttribute("value", information.title);

        infoDescription.setAttribute(
            "value",
            information.description
        );

        infoBox.setAttribute("visible", true);
    });

});


// Close information box
closeButton.addEventListener("click", function () {

    infoBox.setAttribute("visible", false);

});